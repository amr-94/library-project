<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">






                   <div class="row text-center">
                        <div class="col-md-12  col-sm-3">

                        <ul class="nav navbar-nav navbar-right">


                                   <li><a href="<?php echo e(asset('books')); ?>">الكتب</a></li>
                                   <li><a href="<?php echo e(asset('novels')); ?>">الروايات</a></li>

                                   <li><a href="<?php echo e(asset('home')); ?>">الرئيسية</a></li>
                                   <li><a href="<?php echo e(asset('author_page')); ?>">المؤلفون</a></li>


                      </ul>
                        </div>
                   </div>

<div class="row">
    <div class="col-md-12">
        <br>
        <h3 aling="center">Add Novel</h3>
        <br>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
        <?php endif; ?>
        <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
        </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url('novelsbackend')); ?>"  enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


            <div class="form-group">
                <input type="text" name="novel_name" class="form-control" placeholder="Novel Name">
            </div>
            <div class="form-group">
                <input type="text" name="novel_rate" class="form-control" placeholder="Novel rate from 10">
            </div>
            <div class="form-group">
                <input type="text" name="novel_class" class="form-control" placeholder="Novel Class">
            </div>
            <div class="form-group">
                <input type="text" name="novel_des" class="form-control" placeholder="Novel Describtion">
            </div>
            <div class="form-group">
                <p> اضافة صورة
                <input type="file" name="file" class="form-control" >
            </div>
            <div class="form-group">
                <p> pdf اضافة ملف ال
                <input type="file" name="pdf" class="form-control" >
            </div>
            <div class="form-group">
                <label for="author_id">Choose a author :</label>

               <select type="text" name="author_id" class="form-control" >

                <option name=".....">... </option>
                     <?php $__currentLoopData = $author; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <option name="author_id"><?php echo e($author->author_id); ?> </option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
              </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary">
            </div>
        </form>
    </div>
</div>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>


<h2>Author Table</h2>

<table>
  <tr>
    <th>author_id</th>
    <th>author_name</th>
  </tr>
  <?php $__currentLoopData = $amr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
    <td><?php echo e($amr->author_id); ?></td>
    <td><?php echo e($amr->author_name); ?></td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\my-github\library\Backend\resources\views/frontend/ncreate.blade.php ENDPATH**/ ?>