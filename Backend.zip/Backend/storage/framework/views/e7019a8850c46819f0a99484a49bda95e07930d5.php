<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\xampp\htdocs\my-github\library\Backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>