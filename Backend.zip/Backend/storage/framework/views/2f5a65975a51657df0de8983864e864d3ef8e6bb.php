;
<?php $__env->startSection('title','contact-us'); ?>;
    


<?php $__env->startSection("content"); ?>
<div class="container">
   <div class="content">
                <div class="title m-b-md">
                            <?php echo e($title); ?>

                 </div>
   </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/contact.blade.php ENDPATH**/ ?>