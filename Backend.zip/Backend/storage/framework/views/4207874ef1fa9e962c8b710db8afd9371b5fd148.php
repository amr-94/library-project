<DOCTYPE html>
    <!-- ملف التعديل-->
    <html>
        <head>
            <meta charset="UTF-8">
            <title>HOME PAGE</title>
           <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/font_awesome.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/indexstyle.css')); ?>">
            <style>
                /*@import  url('https://fonts.googleapis.com/css2?family=Aref+Ruqaa&display=swap'); */
                @import  url('https://fonts.googleapis.com/css2?family=Aref+Ruqaa&display=swap');
            </style>

        </head>
        <body>
            <section class="header">
              <div class="row">
                <div class="header2 col-md-push-4 col-md-6 col-sm-push-3 col-sm-7 col-xs-push-1 col-xs-11">
                    <br>
                    <h1 class="">اجعل القراءة عادتك اليومية</h1>
                    <br> <br>
                </div>
              </div>
            </section>
            <div style="clear: both"></div>
            <nav class="navbar navbar-default">
              <div class="navv">
                  <div class="container">
                      <br> <br>
                      <!-- Brand and toggle get grouped for better mobile display -->
                      <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                          <a class="navbar-brand" href="#"><img src="./img/logo.jpeg" width="60px" height="60px" style="border-radius: 25px; border: 4px solid #bf9423;"></a>
                      </div>

                      <!-- Collect the nav links, forms, and other content for toggling -->
                      <br>
                      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <ul class="nav navbar-nav">
                            <li><a href="#">ترشيحات الموقع</a></li>
                          </ul>

                                            <ul class="nav navbar-nav navbar-right">
                         <li><a href="<?php echo e(asset('books')); ?>">الكتب</a></li>
                          <li><a href="<?php echo e(asset('novels')); ?>">الروايات</a></li>
                          <li><a href="<?php echo e(asset('author_page')); ?>">المؤلفين</a></li>
                          <li><a href="<?php echo e(asset('index')); ?>">الرئيسية</a></li>


                      </ul>
                      </div>
                      <!-- /.navbar-collapse -->
                      <div class="row text-center">
                          <div class="col-md-8 col-md-push-2 col-xs-12">
                              <div style="height: 80px;  padding: 30px; margin-top: 110px;">
                                  <button type="submit" style="width: 50px;  height: 42px; border: none; background-color: #383531;"><span class="glyphicon glyphicon-search" style="color: darkgoldenrod;"></span></button>
                                  <input type="text" style="width: 320px; padding: 13px 0px 9px 190px; border: none; background-color: #383531; color: darkgoldenrod;" placeholder="تبحث عن كتاب معين">

                              </div>
                          </div>
                      </div>

                      <div class="row text text-center">
                          <div class="text text-center" id="menu">
                              <a href="" style="font-size: 50px; color:#f7bc22; font-family: 'Aref Ruqaa', serif; text-decoration: none;">ترشيحات الموقع</a><br><br><span class="glyphicon glyphicon-chevron-down" style="color:#f7bc22; font-size: 20px;"></span>
                          </div>



                            <section class="container text text-center " style="margin-left:40px;margin-top: 40px; display: none; ;height: 300px;" id="contant">
                                    <?php $__currentLoopData = $amr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                               <div class="row topp">
                              <div class=" col-md-3 col-sm-4 col-xs-12 ">
                                  <div class="thumbnail">
                                      <img src="<?php echo e(asset('img/'.$a->img)); ?>" style="border-radius: 0px; height: 250px; width: 200px; padding-left: 30px;" alt="">
                                      <div class="caption">
                                          <h3 class="text text-center" style="font-family: 'Aref Ruqaa', serif; font-size:30px "><?php echo e($a->book_name); ?></h3>
                                          <p class="text text-center"><a href="<?php echo e('public/../book/'.$a->book_id); ?>" style="color: white; font-weight: bold;">اضغط هنا للتحميل</a></p>
                                      </div>
                                  </div>
                              </div>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                          </section>
                          <br> <br>
                      </div>
                  </div>
                  <!-- /.container-fluid -->
              </div>

         </nav>
                <div style="clear: both"></div>


                <div class="sections container" >
                    <div class="row">
                    <div class=" sec col-md-6 col-sm-6 col-xs-12" style="margin-top: 80px;" >
                        <h2 class="text-center"  style="padding-bottom: 90px; color: black; font-size: 59px; font-family: 'Aref Ruqaa', serif;">الكتب الأكثر قراءة</h2>
                        <div>
                                <div class="col-md-4 col-xs-4">
                                    <img src="./img/8.jpeg" width="100px" height="100px">
                                </div>
                                <div class="col-md-4 col-xs-4">
                                    <img src="./img/14.jpeg" width="100px" height="100px">
                                </div>
                                <div class="col-md-4 col-xs-4">
                                    <img src="./img/13.jpeg" width="100px" height="100px">
                                </div>
                        </div>
                        <br> <br> <br> <br> <br> <br>
                        <div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/5.jpeg" width="100px" height="100px">
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/6.jpeg" width="100px" height="100px">
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/7.jpeg" width="100px" height="100px">
                            </div>
                       </div>
                    <br> <br> <br> <br> <br> <br>
                        <div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/9.jpeg" width="100px" height="100px">
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/10.jpeg" width="100px" height="100px">
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/13.jpeg" width="100px" height="100px">
                            </div>
                    </div>

                    </div>
                    <div class="sec col-md-6 col-sm-6 col-xs-12" style="margin-top: 80px;">
                        <h2 class="text-center" style="padding-bottom: 90px; color: black; font-size: 59px; font-family: 'Aref Ruqaa', serif;">الروايات الأكثر قراءة</h2>
                        <div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/4.jpeg" width="100px" height="100px">
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/3.jpeg" width="100px" height="100px">
                            </div>
                            <div class="col-md-4 col-xs-4">
                                <img src="./img/2.jpeg" width="100px" height="100px">
                            </div>
                    </div>
                    <br> <br> <br> <br> <br> <br>
                    <div>
                        <div class="col-md-4 col-xs-4">
                            <img src="./img/8.jpeg" width="100px" height="100px">
                        </div>
                        <div class="col-md-4 col-xs-4">
                            <img src="./img/14.jpeg" width="100px" height="100px">
                        </div>
                        <div class="col-md-4 col-xs-4">
                            <img src="./img/13.jpeg" width="100px" height="100px">
                        </div>
                   </div>
                <br> <br> <br> <br> <br> <br>
                    <div>
                        <div class="col-md-4 col-xs-4">
                            <img src="./img/8.jpeg" width="100px" height="100px">
                        </div>
                        <div class="col-md-4 col-xs-4">
                            <img src="./img/14.jpeg" width="100px" height="100px">
                        </div>
                        <div class="col-md-4 col-xs-4">
                            <img src="./img/13.jpeg" width="100px" height="100px">
                        </div>
                </div></div></div>
                <div style="clear: both"></div>
            </div>





            <section class="part text text-center" style="margin-top: 80px;">
                <div class="container">

                    <h1 class="text text-center" style="font-family: 'Aref Ruqaa', serif; margin-bottom: 60px;font-size: 59px; color: black; padding-top: 30px;">قسم الكتب</h1>

                <div class="row">
                    <div class="col-sm-6 col-md-3">
                      <div class="thumbnail">
                        <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/book.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                            <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color: lightcoral;">كتب <br>دينية</h3>


                        </div>
                        <div class="caption">
                       <!--   <p style="line-height: 1.62857143; padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                            كثير من الملاحظات اور"

                             </p> -->
                          <p><a href="#" class="btn btn-default" id="btnn" role="button">المزيد</a></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                      <div class="thumbnail">
                        <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/book.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                            <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color:#836fff;">كتب <br>أدبية</h3>


                        </div>
                        <div class="caption">
                        <!--  <p style="line-height: 1.62857143;  padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                            كثير من الملاحظات اور"

                             </p> -->
                          <p><a href="#" class="btn btn-default" id="btnn1" role="button">المزيد</a></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                      <div class="thumbnail">
                        <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/book.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                            <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color: #18f1df;">كتب <br>تاريخية</h3>


                        </div>
                        <div class="caption">
                        <!--  <p style="line-height: 1.62857143;  padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                            كثير من الملاحظات اور"

                             </p> -->
                          <p><a href="#" class="btn btn-default" id="btnn2" role="button">المزيد</a></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                      <div class="thumbnail">
                        <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/book.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                            <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color: #b93ba4;">كتب <br>تعليمية</h3>


                        </div>
                        <div class="caption">
                        <!--  <p style="line-height: 1.62857143; padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                            كثير من الملاحظات اور"

                             </p> -->
                          <p><a href="#" class="btn btn-default" id="btnn3" role="button">المزيد</a></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


            </section> <!--نهاية سيكشن قسم الكتب-->







            <section class="part1 text text-center" style="margin-top: 80px;">
              <div class="container">

                  <h1 class="text text-center" style="font-family: 'Aref Ruqaa', serif; margin-bottom: 60px; font-size: 59px; color: black;">قسم الروايات</h1>

              <div class="row">
                  <div class="col-sm-6 col-md-3">
                    <div class="thumbnail">
                      <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/22.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                          <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color: #a7a7a7;">روايات <br>خيالية</h3>


                      </div>
                      <div class="caption">
                       <!-- <p style="line-height: 1.62857143; padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                          كثير من الملاحظات اور"

                           </p>-->
                        <p><a href="#" class="btn btn-default" id="btnn4" role="button">المزيد</a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-3">
                    <div class="thumbnail">
                      <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/22.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                          <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color:#53c56b;">روايات <br>عالمية</h3>


                      </div>
                      <div class="caption">
                       <!-- <p style="line-height: 1.62857143;  padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                          كثير من الملاحظات اور"

                           </p> -->
                        <p><a href="#" class="btn btn-default" id="btnn5" role="button">المزيد</a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-3">
                    <div class="thumbnail">
                      <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/22.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                          <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color: #de7e2b;">روايات <br>رعب</h3>


                      </div>
                      <div class="caption">
                      <!-- <p style="line-height: 1.62857143;  padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                          كثير من الملاحظات اور"

                           </p> -->
                        <p><a href="#" class="btn btn-default" id="btnn6" role="button">المزيد</a></p>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-3">
                    <div class="thumbnail">
                      <div class="ele1" style="width: 280px; height: 280px; background-image: url(./img/22.jpeg); margin-left: auto; margin-right: auto; border-radius: 200px;">
                          <h3 class="text text-center" style="padding-top: 18px; font-family: 'Aref Ruqaa', serif; font-size: 90px; color: #00a1ffa1;">روايات <br>درامية</h3>


                      </div>
                      <div class="caption">
                       <!-- <p style="line-height: 1.62857143; padding: 15px 0px;">لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع النصوص بالتصاميم سواء كانت تصاميم مطبوعه ... بروشور او فلاير على سبيل المثال ... او نماذج مواقع انترنت ...

                          كثير من الملاحظات اور"

                           </p>-->
                        <p><a href="#" class="btn btn-default" id="btnn7" role="button">المزيد</a></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </section>




          <div style="background-color: #3333330d;">
          <section class="container text text-center section1" style="margin-top: 100px;">  <!--بداية المؤلفين-->
            <h1 class="text text-center" style="font-family: 'Aref Ruqaa', serif; margin-bottom: 100px; font-size: 70px; color: black;" >المؤلفون</h1>
            <div class="row">
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="thumbnail">
                  <img src="./img/روايات-ساندران-براون-768x432.png" style="height: 350px; width: 400px;" alt="">
                  <div class="caption">
                    <h3 style="font-family: 'Aref Ruqaa', serif; padding: 10px 0px 0px 0px; font-size: 35px; color:#f7bc22 ;"> ساندرا لين براون</h3>
                    <p style="height: 150px; margin-top: 40px; margin-bottom: 20px;"> (ولدت في مارس 1948 في واكو، تكساس) هي مؤلفة أمريكية صاحبة أعلى المبيعات لروايات الرومانسية والإثارة.أيضا نشرت براون أعمالا تحت أسماء مستعارة مثل رايتشل رايان، لورا جوردان وإيرين كلير.
                    </p>
                    <p> <a href="#" class="btn btn-default" role="button" style="border: 1.8px solid; border-radius: 15px; color: #060606; background-color: #fff; border-color: #2902ff; padding: 3px 30px;">المزيد</a></p>
                  </div>
                </div>
              </div>

              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="thumbnail">
                  <img src="./img/afeba61f-0c85-4e07-b7e7-5d6bda1945cb.jpg" style="height:350px; width: 400px;" alt="">
                  <div class="caption">
                    <h3 style="font-family: 'Aref Ruqaa', serif; padding: 10px 0px 0px 0px; font-size: 35px; color:#f7bc22 ;">دكتور/احمد خالد توفيق</h3>
                    <p style="height: 150px; margin-top: 40px; margin-bottom: 20px;">طبيب، وكاتب، ومؤلف، ومترجم مصري. يُعد أول كاتب عربي في مجال أدب الرعب. والأشهر في مجال أدب الشباب، والفنتازيا، والخيال العلمي. لُقب بـ"العراب".
                      .
                    </p>
                    <p> <a href="#" class="btn btn-default" role="button" style="border: 1.8px solid; border-radius: 15px; color: #060606; background-color: #fff; border-color: #2902ff; padding: 3px 30px;">المزيد</a></p>
                  </div>
                </div>
              </div>

              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="thumbnail">
                  <img src="./img/أهم_مؤلفات_باولو_كويلو.jpg" style="height:  350px; width: 400px;" alt="">
                  <div class="caption">
                    <h3 style="font-family: 'Aref Ruqaa', serif; padding: 10px 0px 0px 0px; font-size: 35px; color:#f7bc22 ;">باولو كويلو</h3>
                    <p style="height: 150px; margin-top: 40px; margin-bottom: 20px;">روائي وقاص برازيلي ولد (24 اغسطس 1947). يؤلف حاليا القصص المحررة من قبل العامة عن طريق الفيس بوك. تتميز رواياته بمعنى روحي يستطيع العامة تطبيقه مستعملاً شخصيات ذوات مواهب خاصة، لكن متواجدة عند الجميع. كما يعتمد على أحداث تاريخية واقعية لتمثيل أحداث قصصه.
                    </p>
                    <p> <a href="#" class="btn btn-default" role="button" style="border: 1.8px solid; border-radius: 15px; color: #060606; background-color: #fff; border-color: #2902ff; padding: 3px 30px;">المزيد</a></p>
                  </div>
                </div>
              </div>
            </div>


          </section>
        </div>








          <div id="top">
            <button style="background-color:gray; padding: 5px;  border: none;"><span class="glyphicon glyphicon-chevron-up"></span></button>
          </div>


          <section style="background-color: black; height: 200px; margin-top: 100px;">
            <footer class="container">
              <div class="row" style="margin-top: 30px;">
                <div class="col-md-2 col-md-push-1  col-sm-push-6 col-sm-6  col-xs-6 col-xs-push-4">
                  <a href="" style="font-size: 30px; color: #bf9423;">تواصل معنا</a> <br> <br>
                            <i class="fa fa-google" style="font-size: 20px; color: rgb(255, 255, 255); padding: 0px 10px;"></i>
                            <i class="fa fa-facebook" style="font-size: 20px; color: rgb(16, 40, 255); padding: 0px 10px;"></i>
                            <i class="fa fa-twitter" style="font-size: 20px; color: rgb(86, 207, 255); padding: 0px 10px;"></i>
                </div>
                <div class="col-md-6 col-md-push-4 col-sm-push-3 col-sm-9 col-xs-push-1 col-xs-11" style="margin-top: 20px;">
                  <button type="submit" style="width: 50px;  height: 42px; border: none; background-color: #383531;" ><span class="glyphicon glyphicon-search" style="color: darkgoldenrod;"></span></button>
                  <input type="text" style="width: 320px; padding: 13px 0px 9px 190px; border: none; background-color: #383531; color: darkgoldenrod;"  placeholder="تبحث عن كتاب معين">
                </div>
              </div>


            </footer>

          </section>

          <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>">
          </script>
          <script>
              $(document).ready(function() {


                  $("#menu").click(function() {

                      $("#contant").slideToggle(1800);

                  })

              });
              $(function() {
                  $(window).scroll(function() {
                      if ($(this).scrollTop() > 300) {
                          $("#top").fadeIn()
                      } else {
                          $("#top").fadeOut()
                      }

                  })
                  $("#top").click(function() {
                      {
                          $("html, body").animate({
                              scrollTop: 0
                          }, 1000)
                      }
                  })
              });
          </script>
        </body>
    </html>
<?php /**PATH C:\xampp\htdocs\my-github\library\frontend\resources\views/frontend/index.blade.php ENDPATH**/ ?>