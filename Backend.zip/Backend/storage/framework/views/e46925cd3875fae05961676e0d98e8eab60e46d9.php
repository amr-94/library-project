<DOCTYPE html>
    <html>
        <head>
            <meta charset="UTF-8">
            <title>book</title>
           <link rel="stylesheet" href="<?php echo e(asset( 'css/bootstrap.min.css' )); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/font_awesome.min.css')); ?>">
            <link rel="stylesheet" href="<?php echo e(asset('css/bookstyle.css')); ?>">
             <style>
                @import  url('https://fonts.googleapis.com/css2?family=Aref+Ruqaa&display=swap');
            </style>

        </head>
        <body>
            <section class="header">
              <div class="row">
                <div class="header2 col-md-push-4 col-md-6 col-sm-push-3 col-sm-7 col-xs-push-1 col-xs-11">
                    <br>
                    <h1 class="">اجعل القراءة عادتك اليومية</h1>
                    <br> <br>
                </div>
              </div>
            </section>
            <div style="clear: both"></div>
            <nav class="navbar navbar-default">
              <div class="navv">
                  <div class="container">
                      <br> <br>
                      <!-- Brand and toggle get grouped for better mobile display -->
                      <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </button>
                          <a class="navbar-brand" href="#"><img src="./img/logo.jpeg" width="60px" height="60px" style="border-radius: 25px; border: 4px solid #bf9423;"></a>
                      </div>

                      <!-- Collect the nav links, forms, and other content for toggling -->
                      <br>
                      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                          <ul class="nav navbar-nav">
                            <li><a href="#">ترشيحات الموقع</a></li>
                          </ul>

                                               <ul class="nav navbar-nav navbar-right">
                          <li><a href="<?php echo e(asset('books')); ?>">الكتب</a></li>
                          <li><a href="<?php echo e(asset('novels')); ?>">الروايات</a></li>
                          <li><a href="<?php echo e(asset('author_page')); ?>">المؤلفين</a></li>
                          <li><a href="<?php echo e(asset('index')); ?>">الرئيسية</a></li>


                      </ul>
                      </div>
                      <!-- /.navbar-collapse -->
                      <div class="row text-center">
                          <div class="col-md-8 col-md-push-2 col-xs-12">
                              <div style="height: 80px;  padding: 30px; margin-top: 110px;">
                                  <button type="submit" style="width: 50px;  height: 42px; border: none; background-color: #383531;"><span class="glyphicon glyphicon-search" style="color: darkgoldenrod;"></span></button>
                                  <input type="text" style="width: 320px; padding: 13px 0px 9px 190px; border: none; background-color: #383531; color: darkgoldenrod;" placeholder="تبحث عن كتاب معين">

                              </div>
                          </div>
                      </div>

                      <div class="row text text-center">
                          <div class="text text-center" id="menu">
                              <a href="" style="font-size: 50px; color:#f7bc22; font-family: 'Aref Ruqaa', serif; text-decoration: none;">ترشيحات الموقع</a><br><br><span class="glyphicon glyphicon-chevron-down" style="color:#f7bc22; font-size: 20px;"></span>
                          </div>



                           <section class="container text text-center " style="margin-left:40px;margin-top: 40px; display: none; ;height: 300px;" id="contant">
                                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <div class="row topp">
                              <div class=" col-md-3 col-sm-4 col-xs-12 ">
                                  <div class="thumbnail">
                                      <img src="<?php echo e(asset('img/'.$a->img)); ?>" style="border-radius: 0px; height: 250px; width: 200px; padding-left: 30px;" alt="">
                                      <div class="caption">
                                          <h3 class="text text-center" style="font-family: 'Aref Ruqaa', serif; font-size:30px "><?php echo e($a->book_name); ?></h3>
                                          <p class="text text-center"><a href="<?php echo e('../book/'.$a->book_id); ?>" style="color: white; font-weight: bold;">اضغط هنا للتحميل</a></p>
                                      </div>
                                  </div>
                              </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>

                      </section>










                          <br> <br>
                      </div>
                  </div>
                  <!-- /.container-fluid -->
              </div>


          </nav>




          <section class="container" style="margin-top: 80px;">
            <h1 class="text text-center" style="font-family: 'Aref Ruqaa', serif; font-size: 56px; margin-bottom: 80px; color: black;">معلومات الكتاب</h1>
            <div class="row">
                <div class=" col-md-6  col-xs-12 col-sm-12 ">
                    <img src="<?php echo e(asset('img/'.$data->img)); ?>" style=" border-radius: 25px; border: 2px solid #f8e1a6; height: 400px; width: 300px; margin-bottom: 10px;" id="im">
                </div>


                <div class="col-md-6 col-xs-12 col-sm-12">
                    <h2 class="text text-center" style=" color: #f7bc22; margin-bottom: 55px; font-family: 'Aref Ruqaa', serif; font-size: 40px;"><?php echo e($data->book_name); ?></h2>
                    <p class="text text-center" style="text-align: center;  font-size: 18px;">
                      <?php echo e($data->book_des); ?>

                    </p>
                    <br>

                    <hr>
                   <p class="text text-center"> <a href="https://www.noor-book.com/%D9%83%D8%AA%D8%A7%D8%A8-%D8%A7%D9%84%D8%B1%D8%AD%D9%8A%D9%82-%D8%A7%D9%84%D9%85%D8%AE%D8%AA%D9%88%D9%85-pdf" class="btn11 btn btn-default" role="button">اضغط هنا لتحميل الكتاب</a></p>

                </div>
            </div>
        </section>



        <div class="" style="background-color:  #eceaea ;">
        <section class="cont container" style="margin-top: 50px;margin-right: 50px;">
            <h2 class="text text-center" style="font-family: 'Aref Ruqaa', serif; font-size: 60px; margin-bottom:80px; ">كتب أخرى</h2>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" row">
              <div class="col-xs-12 col-md-3 col-sm-6 " style="margin-right: 50px;">
                  <div class="thumbnail">
                      <img src="<?php echo e(asset('img/'.$a->img)); ?>" style="height: 400px; border-radius: 0px;" alt="">
                      <div class="caption">
                        <h3 class="text text-center"style="font-family: 'Aref Ruqaa', serif; font-size:30px;color:  #f7bc22;"><?php echo e($a->book_name); ?></h3>
                        <p class="text text-center"><a href="<?php echo e('../book/'.$a->book_id); ?>"style="color: #000;font-size: medium;" >اضغط هنا </a></p>
                      </div>
                    </div>

              </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>

            </div>

            </section>





          <div id="top">
            <button style="background-color:gray; padding: 5px;  border: none;"><span class="glyphicon glyphicon-chevron-up"></span></button>
          </div>


          <section style="background-color: black; height: 200px; margin-top: 50px;">
            <footer class="container">
              <div class="row" style="margin-top: 30px;">
                <div class="col-md-2 col-md-push-1  col-sm-push-6 col-sm-6  col-xs-6 col-xs-push-4">
                  <a href="" style="font-size: 30px; color: #bf9423;">تواصل معنا</a> <br> <br>
                            <i class="fa fa-google" style="font-size: 20px; color: rgb(255, 255, 255); padding: 0px 10px;"></i>
                            <i class="fa fa-facebook" style="font-size: 20px; color: rgb(16, 40, 255); padding: 0px 10px;"></i>
                            <i class="fa fa-twitter" style="font-size: 20px; color: rgb(86, 207, 255); padding: 0px 10px;"></i>
                </div>
                <div class="col-md-6 col-md-push-4 col-sm-push-3 col-sm-9 col-xs-push-1 col-xs-11" style="margin-top: 20px;">
                  <button type="submit" style="width: 50px;  height: 42px; border: none; background-color: #383531;" ><span class="glyphicon glyphicon-search" style="color: darkgoldenrod;"></span></button>
                  <input type="text" style="width: 320px; padding: 13px 0px 9px 190px; border: none; background-color: #383531; color: darkgoldenrod;"  placeholder="تبحث عن كتاب معين">
                </div>
              </div>


            </footer>

          </section>

          <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>">
          </script>
          <script>
              $(document).ready(function() {


                  $("#menu").click(function() {

                      $("#contant").slideToggle();

                  })

              });
              $(function() {
                  $(window).scroll(function() {
                      if ($(this).scrollTop() > 300) {
                          $("#top").fadeIn()
                      } else {
                          $("#top").fadeOut()
                      }

                  })
                  $("#top").click(function() {
                      {
                          $("html, body").animate({
                              scrollTop: 0
                          }, 1000)
                      }
                  })
              });
          </script>
        </body>
    </html>
<?php /**PATH C:\xampp\htdocs\my-github\library\frontend\resources\views/frontend/book.blade.php ENDPATH**/ ?>