<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <br>
        <h3 aling="center">Add Author</h3>
        <br>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
        <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
        <?php endif; ?>
        <?php if(\Session::has('success')): ?>
        <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
        </div>
        <?php endif; ?>   

        <form method="post" action="<?php echo e(url('authorsbackend')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="text" name="author_id" class="form-control" placeholder="Author ID">
            </div>
            <div class="form-group">
                <input type="text" name="author_name" class="form-control" placeholder="Author Name">
            </div>
            <div class="form-group">
                <input type="text" name="author_rate" class="form-control" placeholder="Author rate from 10">
            </div>
            <div class="form-group">
                <!--<input type="text" name="nationality" class="form-control" placeholder="Author Nationality">-->
                <select name="nationality" class="form-control" placeholder="Author Nationality">
                    <option value="Egyptian">Egyptian</option>
                    <option value="Algerian">Algerian</option>
                    <option value="Lebanese">Lebanese</option>
                    <option value="Moroccan">Moroccan</option>
                    <option value="Palestinian">Palestinian</option>
                    <option value="Saudi Arabian">Saudi Arabian</option>
                    <option value="other..">other..</option>
                  </select>
            </div>
            <div class="form-group">
                <input type="text" name="about_author" class="form-control" placeholder="About Author">
            </div>
            <div class="form-group">
                <input type="text" name="author_des" class="form-control" placeholder="Author Describtion">
            </div>
            <div class="form-group">
                <input type="file" name="img" class="form-control" placeholder="Author photo">
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary">
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\frontend\resources\views/frontend/acreate.blade.php ENDPATH**/ ?>